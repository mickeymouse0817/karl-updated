import { Document } from "mongodb";
import mongoose, { Schema } from "mongoose";

interface IUser {
  name: string;
  first_name: string;
  last_name: string;
  chatid: number;
}

const UserScheme: Schema = new Schema({
  name: {type: String},
  first_name: {type: String},
  last_name: {type: String},
  chatid: {type: Number, unique: true}
})

export const UserModel = mongoose.model<IUser>('User', UserScheme)