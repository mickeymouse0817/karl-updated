import { getCurrentTimestamp, PF_WALLET, pfGetTokenDataByApi, solTrGrpcPfStart, solWalletImport } from "dv-sol-lib";
import connectDB from "./db";
import { dbTokenAdd } from "./db/db.service/service.token";
import dotenv from 'dotenv'
import { doSniper } from "./middlware/sniper";
import { Connection, PublicKey, Commitment, GetSlotConfig } from '@solana/web3.js';
import axios from 'axios';
import { config } from "./config";
import { tokenAdd } from "./middlware/token";
import { botStart } from "./bot";

console.log('\n====================================');
console.log('🚀 STARTING BOT...');
console.log('====================================\n');

dotenv.config()

// Connection details logging
const RPC_URL = process.env.RPC_URL || 'default RPC';
const GRPC_URL = process.env.GRPC_URL || 'default GRPC';

console.log('📡 Connection Details:');
console.log(`   RPC URL: ${RPC_URL}`);
console.log(`   GRPC URL: ${GRPC_URL}\n`);

// Declare gSigner at the top level
let gSigner: any;

// Add this debug code here to inspect the solWalletImport function
console.log('\n📚 Checking solWalletImport function:');
console.log(solWalletImport.toString());

// Create a global connection instance
let solanaConnection: Connection;

// Define the transaction analyzer function
async function pfTrDataAnalyzer(data: any) {
    if (!data) {
        console.log('❌ Received empty data in analyzer');
        return;
    }

    // console.log(`\n🔄 New Transaction: ${data.type}`);

    switch (data.type) {
        case 'Mint':
            // console.log(`🌟 Mint detected for token: ${data.token}`);
            break;

        case 'Migration':
            console.log(`\n🚀 MIGRATION DETECTED`);
            console.log(`📍 Token Address: ${data.token}`);
            console.log(`  Market Maker: ${data.marketMaker}`);

            try {
                console.log('📊 Fetching token data...');
                const token = data.token;

                if (data.marketMaker !== PF_WALLET) {
                    throw new Error(`Fake pumpfun token. marketMaker = ${data.marketMaker}`)
                }
                const tokenInfo = await pfGetTokenDataByApi(token)
                // Detailed validation
                if (!tokenInfo) {
                    throw new Error('Token info response is empty');
                }

                if (typeof tokenInfo.created_timestamp === 'undefined') {
                    console.log('\n⚠️ Available fields in response:', Object.keys(tokenInfo));
                    throw new Error('Token info missing created_timestamp');
                }

                const stayedOnPF = (getCurrentTimestamp() - tokenInfo.created_timestamp) / 1000;
                const elapsedAfterKof = (getCurrentTimestamp() - tokenInfo.king_of_the_hill_timestamp) / 1000;

                console.log('\n📈 Token Analysis:');
                console.log(`   Time on PumpFun: ${stayedOnPF} seconds`);
                console.log(`   Creator: ${tokenInfo.creator || 'Unknown'}`);

                // record token information to db
                const parsedInfo = {
                    address: tokenInfo.mint,
                    name: tokenInfo.name,
                    symbol: tokenInfo.symbol,
                    twitter: tokenInfo.twitter,
                    telegram: tokenInfo.telegram,
                    creator: tokenInfo.creator,
                    delayedOnPump: stayedOnPF,
                    elapsedAfterKof: elapsedAfterKof
                }
                tokenAdd(parsedInfo)
                console.log(`\n🎯 Starting sniper process for token: ${tokenInfo.mint} ...`);
                await doSniper(data, parsedInfo);
                console.log('✅ Sniper process completed');
            } catch (error: any) {
                console.log(`\n❌ Error in migration process: ${error.message || error}`);
                const errorDetails = {
                    token: data.token,
                    errorType: error?.constructor?.name || 'Unknown',
                    errorMessage: error?.message || 'No error message',
                    errorStack: error?.stack || 'No stack trace',
                    timestamp: new Date().toISOString(),
                    apiEndpoint: `https://frontend-api.pump.fun/coins/${data.token}`
                };
                console.log('   Full Error Details:', JSON.stringify(errorDetails, null, 2));
            }
            break;

        default:
            // console.log(`ℹ️ Unhandled transaction type: ${data.type}`);
            break;
    }
}

async function main() {
    console.log('\n====================================');
    console.log('🚀 STARTING BOT...');
    console.log('====================================\n');
    // start the telegram bot
    botStart()
    // Use ENDPOINT instead of RPC_URL
    if (!RPC_URL) {
        console.log('❌ No ENDPOINT found in environment variables!');
        console.log('   Please ensure your .env file contains: ENDPOINT="https://rpc.shyft.to?api_key=..."');
        process.exit(1);
    }

    console.log('📡 Connection Details:');
    console.log(`   RPC URL: ${RPC_URL}`);
    console.log(`   GRPC URL: ${process.env.GRPC_URL || 'default GRPC'}\n`);

    // Initialize Solana connection
    solanaConnection = new Connection(RPC_URL, 'confirmed');

    // Test connection before proceeding
    try {
        const slot = await solanaConnection.getSlot();
        console.log('✅ RPC Connection verified:');
        console.log(`   Current slot: ${slot}`);
        // @ts-ignore - accessing internal property
        console.log(`   Using endpoint: ${solanaConnection._rpcEndpoint}`);
    } catch (error) {
        console.log('❌ Failed to connect to RPC:');
        console.log(`   ${error}`);
        process.exit(1);
    }

    // Initialize wallet
    console.log('\n🔑 Importing wallet...');
    try {
        gSigner = solWalletImport(process.env.PRIVATE_KEY!);

        if (!gSigner || !gSigner.publicKey) {
            throw new Error('Wallet import failed');
        }

        const walletBalance = await solanaConnection.getBalance(gSigner.publicKey);
        console.log('✅ Wallet imported successfully:');
        console.log(`   Address: ${gSigner.publicKey.toString()}`);
        console.log(`   Balance: ${walletBalance / 1e9} SOL`);
    } catch (error) {
        console.log('❌ Failed to verify wallet:');
        console.log(`   ${error}`);
        process.exit(1);
    }

    // Debug function to check connection details
    function logConnectionDetails() {
        console.log('\n🔍 Connection Details:');
        if (!gSigner) {
            console.log('❌ No wallet initialized');
            return;
        }

        console.log(`   Wallet Public Key: ${gSigner.publicKey?.toString()}`);
        // @ts-ignore - accessing internal property
        console.log(`   RPC Endpoint: ${solanaConnection._rpcEndpoint}`);

        // Test actual RPC call
        solanaConnection.getSlot()
            .then(slot => console.log(`   ✅ Current slot: ${slot}`))
            .catch(err => console.log(`   ❌ RPC call failed: ${err}`));
    }

    // Log initial connection details
    logConnectionDetails();

    // Start periodic connection checks
    setInterval(logConnectionDetails, 30000);

    // Initialize other services
    console.log('\n🔌 Connecting to database...');
    await connectDB();

    // Start GRPC with the analyzer
    console.log('\n📡 Initializing GRPC connection...');
    await solTrGrpcPfStart(pfTrDataAnalyzer);
    console.log('✅ GRPC connection established');
    console.log('\n👀 Bot is now monitoring for new transactions...\n');
}

// Export gSigner for use in other modules
export { gSigner, solanaConnection };

main().catch(error => {
    console.log('❌ Fatal error:');
    console.log(`   ${error}`);
    process.exit(1);
});
