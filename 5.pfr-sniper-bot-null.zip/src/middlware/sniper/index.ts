import { generateEventWithPercentage, getCurrentTimestamp, getRandomNumber, sleep, SOL_ACCOUNT_RENT_FEE, solBlockTimeGet, solPFGetTokensCreatedByWallet, solRaydiumSwap, solRaydiumswapCalcAmountOut, solTokenBalance, solTrGetBalanceChange, solTrGetTimestamp } from "dv-sol-lib"
import { gSigner } from "../.."
import { config } from "../../config"
import { LiquidityPoolKeys } from "@raydium-io/raydium-sdk"
import { tgbotBroadcastMsg } from "../tgbot"

async function getTokenBalance(token: string): Promise<bigint> {
  let tokenBalance = BigInt('0')
  const startTm = getCurrentTimestamp()
  while (!tokenBalance) {
    if (getCurrentTimestamp() - startTm > 60000)
      break
    try {
      tokenBalance = (await solTokenBalance(token, gSigner.publicKey))[0]
      if (tokenBalance)
        return tokenBalance
    } catch (error) { }
    await sleep(300)
  }
  return tokenBalance
}

async function isNeedToBuy(tokenInfo: any): Promise<boolean> {
  const tokenAddr = tokenInfo.address
  if (config.allToken)
    return true
  if (config.whitelist.find((wt: string) => wt === tokenInfo.creator)) {
    console.log(`\n🤍 Whitelist token! (${tokenAddr})`);
    return true
  }
  if (config.blacklist.find((wt: string) => wt === tokenInfo.creator)) {
    console.log(`\n🚫 Blacklist token! (${tokenInfo.creator})`);
    return false
  }

  if (config.nullToken === true && tokenInfo.twitter === null && tokenInfo.telegram === null) {
    console.log(`\n🤍 All socials are null.`);
    return true
  }
  
  if (tokenInfo.delayedOnPump > config.stayMax) {
    console.log(`\n🤍 Stayed time on pumpfun is enough to buy.`);
    return true
  }

  if (tokenInfo.initialBuy > 80) {
    console.log(`\n🤍 Initial buy is much enough.`);
    return true
  }
  console.log(`\n⏭️  Skip to sniper (stay on pumpfun is in skip range (${config.stayMin} ~ ${config.stayMax}}) s)...`);
  return false
}

async function isNeedToSell(estAmount: number, boughtAmount: number, sellStartTm: number): Promise<boolean> {
  const percent = (estAmount / boughtAmount) * 100
  const tp = percent - 100
  const sl = 100 - percent
  if (tp > config.tp) {
    console.log(`[LOG](trade) TP meet! ${tp} %`)
    return true
  }
  if (sl > config.sl) {
    console.log(`[LOG](trade) SL meet! ${sl} %`)
    return true
  }
  const elapsedTime = (getCurrentTimestamp() - sellStartTm) / 1000
  if (elapsedTime > config.timeout) {
    console.log(`[LOG](trade) Timeout! ${elapsedTime} s`)
    return true
  }
  return false
}

async function reportBought(tx: string, startBlock: number) {
  const trTime = await solTrGetTimestamp(tx)
  if (!trTime)
    return
  console.log(`[LOG] +++++++++++++ bought after ${trTime.blockNumber - startBlock} blocks`)
}

async function waitForPriceDown(token: string, poolKey: LiquidityPoolKeys, timeout: number, downPercent: number): Promise<boolean> {
  // price monitoring
  console.log(`[LOG](${token}) Price monitoring ...`)
  let retryCnt = 0
  let initialAmount = 0
  while (retryCnt++ < 5) {
    try {
      const initialBuyAmount = await solRaydiumswapCalcAmountOut(poolKey, config.tradeAmount, true)
      initialAmount = parseFloat(initialBuyAmount.minAmountOut.toFixed(3))
      if (initialAmount)
        break
    } catch (error) { }
    await sleep(500)
  }
  if (!initialAmount) {
    console.log(`[LOG](waitForPriceDown) Cannot get the initial amount!`)
    return true
  }

  const startTm = getCurrentTimestamp()
  while (true) {
    if (getCurrentTimestamp() - startTm > timeout) {
      console.log(`[LOG] Price didn't down to ${downPercent}% in ${timeout/1000} secondes. skipping...`)
      return false
    }
    try {
      const curAmount = await solRaydiumswapCalcAmountOut(poolKey, config.tradeAmount, true)
      const curAmountToBuy = parseFloat(curAmount.minAmountOut.toFixed(3))
      const percent = 0 - (((curAmountToBuy / initialAmount) - 1) * 100)
      if (curAmountToBuy !== initialAmount)
        console.log(`[LOG](${token})(BUY-WAIT) ${curAmountToBuy}/${initialAmount} (${percent.toFixed(3)} %, target: ${-downPercent} %)`)
      if (curAmountToBuy > initialAmount * ((100 + downPercent) / 100))
        break
    } catch (error) { }
    await sleep(500)
  }
  return true
}

async function buy(token: string, poolKey: LiquidityPoolKeys): Promise<any> {
  let retryCnt = 0
  let tx: any

  while (true) {
    tx = await solRaydiumSwap(gSigner, poolKey, config.tradeAmount, true, config.jitoBuyTip)
    if (!tx || tx === '') {
      if (++retryCnt > config.retryCount) {
        console.log(`[LOG] Failed to buy.`)
        return undefined
      }
      await sleep(200)
      continue
    }

    console.log(`[LOG] buy tx =`, tx)
    // balance check
    let tokenBalance
    const startTm = getCurrentTimestamp()
    do {
      if (getCurrentTimestamp() - startTm > 30000)
        break
      tokenBalance = await getTokenBalance(token)
      await sleep(1000)
    } while (!tokenBalance);
    if (tokenBalance) {
      break
    }
    if (++retryCnt > config.retryCount) {
      console.log(`[LOG] Failed to buy.`)
      return undefined
    }
  }
  return tx
}

async function sell(poolKey: any, token: string, tx: string, addLiqBlock: number) {
  // balance check
  let tokenBalance = await getTokenBalance(token)
  if (!tokenBalance) {
    console.log(`[LOG] Failed to buy. (Balance zero) skipping ...`)
    return
  }

  let investAmount = await solTrGetBalanceChange(tx)
  if (investAmount) {
    investAmount = (0 - investAmount) - SOL_ACCOUNT_RENT_FEE
  } else {
    investAmount = config.tradeAmount
  }

  reportBought(tx, addLiqBlock)
  // sell process
  let estimatingSolAmount = 0
  const sellStartTm = getCurrentTimestamp()
  let sellTx
  while (tokenBalance) {
    try {
      const estimatedSellInfo = await solRaydiumswapCalcAmountOut(poolKey, tokenBalance, false)
      const expectingAmount = parseFloat(estimatedSellInfo.amountOut.toFixed())
      const tp = parseFloat(((expectingAmount / investAmount) * 100).toFixed(3))
      if (estimatingSolAmount != expectingAmount) {
        const passed = (getCurrentTimestamp() - sellStartTm) / 1000
        console.log(`[LOG](${token}) ******** (${expectingAmount}/${investAmount})(${tp} %) passed: ${passed} s`)
        estimatingSolAmount = expectingAmount
      }
      if (await isNeedToSell(expectingAmount, investAmount, sellStartTm)) {
        if (tp < 20) {
          console.log(`[LOG](${token}) ******** TP is quite low. return without selling ...`)
          return
        }
        sellTx = await solRaydiumSwap(gSigner, poolKey, tokenBalance, false, config.jitoSellTip)
      }
      tokenBalance = await getTokenBalance(token)
    } catch (error) { }
    await sleep(500)
  }
  console.log(`[LOG](${token}) sell finished. tx =`, sellTx)
}

export async function doSniper(data: any, tokenInfo: any) {
  const poolKey = data.poolKey
  const token = data.token

  if ((await isNeedToBuy(tokenInfo)) === false)
    return

  tgbotBroadcastMsg(`https://photon-sol.tinyastro.io/en/lp/${poolKey.id}
    token: <code>${token}</code>
    pair: <code>${poolKey.id}</code>`)
  console.log(`[LOG](${token}) snipping ...`)

  if (config.priceMonitor.enabled) {
    const downPercent = getRandomNumber(config.priceMonitor.from, config.priceMonitor.to)
    const dTimeout = config.priceMonitor.timeout * 1000
    let probability
    if (tokenInfo.delayedOnPump < config.stayMax && tokenInfo.twitter === null && tokenInfo.telegram === null) {
      probability = config.priceMonitor.probability.nullToken
    } else {
      probability = config.priceMonitor.probability.longToken
    }
    const startFlag = generateEventWithPercentage(probability)
    if (startFlag && await waitForPriceDown(token, poolKey, dTimeout, downPercent) === false)
      return
  }

  // buy
  console.log(`[LOG](${token}) buying ...`)
  const tx = await buy(token, poolKey)
  // sell
  sell(poolKey, token, tx, data.block)
}
