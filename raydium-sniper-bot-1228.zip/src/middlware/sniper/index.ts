import { getCurrentTimestamp, sleep, SOL_ACCOUNT_RENT_FEE, solBlockTimeGet, solPFGetTokensCreatedByWallet, solRaydiumSwap, solRaydiumswapCalcAmountOut, solTokenBalance, solTrGetBalanceChange, solTrGetTimestamp } from "dv-sol-lib"
import { gSigner } from "../.."
import { config } from "../../config"
import { LiquidityPoolKeys } from "@raydium-io/raydium-sdk"
import { tgbotBroadcastMsg } from "../tgbot"

async function getTokenBalance(token: string): Promise<bigint> {
  let tokenBalance = BigInt('0')
  const startTm = getCurrentTimestamp()
  while (!tokenBalance) {
    if (getCurrentTimestamp() - startTm > 60000)
      break
    try {
      tokenBalance = (await solTokenBalance(token, gSigner.publicKey))[0]
      if (tokenBalance)
        return tokenBalance
    } catch (error) { }
    await sleep(300)
  }
  return tokenBalance
}

async function isNeedToBuy(tokenInfo: any): Promise<boolean> {
  const tokenAddr = tokenInfo.address
  if (config.whitelist.find((wt: string) => wt === tokenInfo.creator)) {
    console.log(`\n🤍 Whitelist token! (${tokenAddr})`);
    return true
  }
  if (config.blacklist.find((wt: string) => wt === tokenInfo.creator)) {
    console.log(`\n🚫 Blacklist token! (${tokenInfo.creator})`);
    return false
  }
  if (tokenInfo.delayedOnPump > config.stayMax/* || tokenInfo.delayedOnPump < config.stayMin*/) {
    console.log(`\n🤍 Stayed time on pumpfun is enough to buy.`);
    return true
  }
  if (tokenInfo.initialBuy > 80) {
    console.log(`\n🤍 Initial buy is much enough.`);
    return true
  }
  // const createdTokens: any = await solPFGetTokensCreatedByWallet(tokenInfo.creator)
  // if (createdTokens && createdTokens.length > 1) {
  //   console.log(`\n🚫 This creator has already created token on pump.fun.`);
  //   return false
  // }
  // if (Math.random() > 0.5) {
  //   console.log(`\n🎲 Randomize buy (${tokenAddr})`);
  //   return true
  // }
  console.log(`\n⏭️  Skip to sniper (stay on pumpfun is in skip range (${config.stayMin} ~ ${config.stayMax}}) s)...`);
  return false
}

async function isNeedToSell(estAmount: number, boughtAmount: number, sellStartTm: number): Promise<boolean> {
  const percent = (estAmount / boughtAmount) * 100
  const tp = percent - 100
  const sl = 100 - percent
  if (tp > config.tp) {
    console.log(`[LOG](trade) TP meet! ${tp} %`)
    return true
  }
  if (sl > config.sl) {
    console.log(`[LOG](trade) SL meet! ${sl} %`)
    return true
  }
  const elapsedTime = (getCurrentTimestamp() - sellStartTm) / 1000
  if (elapsedTime > config.timeout) {
    console.log(`[LOG](trade) Timeout! ${elapsedTime} s`)
    return true
  }
  return false
}

async function reportBought(tx: string, startBlock: number) {
  const trTime = await solTrGetTimestamp(tx)
  if (!trTime)
    return
  console.log(`[LOG] +++++++++++++ bought after ${trTime.blockNumber - startBlock} blocks`)
}

async function buy(token: string, poolKey: LiquidityPoolKeys): Promise<any> {
  let retryCnt = 0
  let tx: any
  while (true) {
    tx = await solRaydiumSwap(gSigner, poolKey, config.tradeAmount, true, config.jitoBuyTip)
    if (!tx || tx === '') {
      if (++retryCnt > config.retryCount) {
        console.log(`[LOG] Failed to buy.`)
        return undefined
      }
      await sleep(200)
      continue
    }

    console.log(`[LOG] buy tx =`, tx)
    // balance check
    let tokenBalance
    const startTm = getCurrentTimestamp()
    do {
      if (getCurrentTimestamp() - startTm > 30000)
        break
      tokenBalance = await getTokenBalance(token)
      await sleep(1000)
    } while (!tokenBalance);
    if (tokenBalance) {
      break
    }
    if (++retryCnt > config.retryCount) {
      console.log(`[LOG] Failed to buy.`)
      return undefined
    }
  }
  return tx
}

async function sell(poolKey: any, token: string, tx: string, addLiqBlock: number) {
  // balance check
  let tokenBalance = await getTokenBalance(token)
  if (!tokenBalance) {
    console.log(`[LOG] Failed to buy. (Balance zero) skipping ...`)
    return
  }

  let investAmount = await solTrGetBalanceChange(tx)
  if (investAmount) {
    investAmount = (0 - investAmount) - SOL_ACCOUNT_RENT_FEE
  } else {
    investAmount = config.tradeAmount
  }

  reportBought(tx, addLiqBlock)
  // sell process
  let estimatingSolAmount = 0
  const sellStartTm = getCurrentTimestamp()
  let sellTx
  while (tokenBalance) {
    try {
      const estimatedSellInfo = await solRaydiumswapCalcAmountOut(poolKey, tokenBalance, false)
      const expectingAmount = parseFloat(estimatedSellInfo.amountOut.toFixed())
      const tp = parseFloat(((expectingAmount / investAmount) * 100).toFixed(3))
      if (estimatingSolAmount != expectingAmount) {
        const passed = (getCurrentTimestamp() - sellStartTm) / 1000
        console.log(`[LOG](${token}) ******** (${expectingAmount}/${investAmount})(${tp} %) passed: ${passed} s`)
        estimatingSolAmount = expectingAmount
      }
      if (await isNeedToSell(expectingAmount, investAmount, sellStartTm)) {
        if (tp < 20) {
          console.log(`[LOG](${token}) ******** TP is quite low. return without selling ...`)
          return
        }
        sellTx = await solRaydiumSwap(gSigner, poolKey, tokenBalance, false, config.jitoSellTip)
      }
      tokenBalance = await getTokenBalance(token)
    } catch (error) { }
    await sleep(500)
  }
  console.log(`[LOG](${token}) sell finished. tx =`, sellTx)
}

export async function doSniper(data: any, tokenInfo: any) {
  const poolKey = data.poolKey
  const token = data.token

  if ((await isNeedToBuy(tokenInfo)) === false)
    return

  tgbotBroadcastMsg(`https://photon-sol.tinyastro.io/en/lp/${poolKey.id}
    <code>${token}</code>`)
  console.log(`[LOG](${token}) snipping ...`)
  // price monitoring
  // console.log(`[LOG](${token}) Price monitoring ...`)
  // const initialBuyAmount = await solRaydiumswapCalcAmountOut(poolKey, config.tradeAmount, true)
  // const initialAmount = parseFloat(initialBuyAmount.minAmountOut.toFixed(3))
  // const startTm = getCurrentTimestamp()
  // if (Math.random() > 0.5) {
  //   while (true) {
  //     if (getCurrentTimestamp() - startTm > 2 * 60 * 1000) {
  //       console.log(`[LOG] Price didn't down to 50% in 5 minutes. skipping...`)
  //       return
  //     }
  //     try {
  //       const curAmount = await solRaydiumswapCalcAmountOut(poolKey, config.tradeAmount, true)
  //       const curAmountToBuy = parseFloat(curAmount.minAmountOut.toFixed(3))
  //       if (curAmountToBuy !== initialAmount)
  //         console.log(`[LOG](${token})(BUY-WAIT) ${curAmountToBuy}/${initialAmount} (${(curAmountToBuy / initialAmount).toFixed(3)})`)
  //       if (curAmountToBuy > initialAmount * 2) // price down to 100 %
  //         break
  //     } catch (error) { }
  //     await sleep(500)
  //   }
  // }

  // buy
  console.log(`[LOG](${token}) buying ...`)
  const tx = await buy(token, poolKey)
  // sell
  sell(poolKey, token, tx, data.block)
}
