import { botSendMessage } from "../../bot";
import { dbUserGetChatList } from "../../db/db.service/service.user";

export async function tgbotBroadcastMsg(msg: string): Promise<any> {
  const botUsers = await dbUserGetChatList()
  botUsers.forEach(chatId => {
    botSendMessage(chatId, msg)
  });
}