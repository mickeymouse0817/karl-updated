import { UserModel } from "../db.model/model.users";

export async function dbUserAdd(tgChatInfo:any): Promise<any> {
  let user = await UserModel.findOne({
    chatid: tgChatInfo.id
  })
  if (!user) {
    user = new UserModel({
      name: tgChatInfo.username,
      first_name: tgChatInfo.first_name,
      last_name: tgChatInfo.last_name,
      chatid: tgChatInfo.id
    })
    await user.save()
  }
  return user
}

export async function dbUserGetChatList(): Promise<number[]> {
  const users = await UserModel.find({})
  return users.map((user:any) => user.chatid)
}