import TelegramBot, { Message } from "node-telegram-bot-api";
import { dbUserAdd } from "../db/db.service/service.user";

export async function botMessageHandler(bot: TelegramBot, msg: Message): Promise<any> {
  // console.log(msg.chat)
  try {
    switch(msg.text) {
      case '/start':
        await dbUserAdd(msg.chat)
        break
    } 
  } catch (error) {
    
  }
}